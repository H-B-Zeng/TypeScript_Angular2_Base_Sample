"use strict";
var MyModel = (function () {
    function MyModel() {
        this.compiler = "TypeScript";
    }
    return MyModel;
}());
exports.MyModel = MyModel;
//# sourceMappingURL=model.js.map