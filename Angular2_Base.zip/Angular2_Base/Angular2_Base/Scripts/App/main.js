"use strict";
var browser_1 = require("angular2/platform/browser");
var app_1 = require("./app");
browser_1.bootstrap(app_1.MyApp);
//# sourceMappingURL=main.js.map