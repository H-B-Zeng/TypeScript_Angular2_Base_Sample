﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Angular2_Base.Startup))]
namespace Angular2_Base
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
