﻿export class MyModel {
    compiler = "TypeScript";
}